//
//  main.cpp
//  AirlinerC++
//
//  Created by omar on 11/19/22.
//

#include <iostream>
#include <map>
#include <vector>

#include "routes_h.h"
#include "airports_h.h"
#include "read_write_h.h"

using namespace std;

int main(){
    
//    fstream file;
//    file.open("my test output file2.txt", ios::out);
    
    string airport_filename = "airports.csv";

    string airRoute_filename = "routes.csv";

    map<vector<string>, Airport> airport_map;
    airport_map = Airport::AirportFileReader(airport_filename);
//    Airport::printMap(myAirportMap);

    map<string, vector<string>> airport_routemap;
    airport_routemap = Route::AirportRouteReader(airRoute_filename);
//    Route::printMap(myAirRoutesMap);

    map<vector<string>, vector<string>> airline_routemap;
    airline_routemap = Route::AirlineRouteReader(airRoute_filename);
//    Route::printMap(myAirRoutesMap);
    
    string filename;
    cout << "> enter the input file name: ";
    cin >>  filename;
    
    ReadWrite::inputFileReader(filename);
//
}
